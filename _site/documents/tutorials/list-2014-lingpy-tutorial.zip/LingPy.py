# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <headingcell level=1>

# Basics

# <headingcell level=2>

# Loading LingPy

# <codecell>

from lingpy import * # basic functionalities of LingPy
from lingpy.compare.phylogeny import * # borrowing detection class PhyBo
from lingpy.convert.plot import * # general plot module 
from lingpy.evaluate.acd import * # evaluation module for cognate detection 
from IPython.core.display import Image # only for ipython-rendering in this context

# <headingcell level=2>

# Loading Data

# <codecell>

wl = Wordlist('BAI.qlc')

# <headingcell level=2>

# Checking Data

# <codecell>

number_of_taxa = wl.width
number_of_concepts = wl.height
number_of_entries = len(wl)
print("Wordlist has {0} entries, distributed over {1} languages and {2} concepts.".format(number_of_entries, number_of_taxa, number_of_concepts))

# <headingcell level=2>

# Retrieve data

# <codecell>

ashes = wl.get_dict(concept='ashes', entry='ipa')
for a,b in sorted(ashes.items(), key=lambda x:x[0]): 
    print("{0:10}".format(a),"\t",b[0])

# <headingcell level=2>

# Manipulate data

# <codecell>

msa = Multiple(sorted([v[0] for v in ashes.values()]))
msa.lib_align()
print(msa)

# <headingcell level=1>

# Find Cognates

# <codecell>

lex = LexStat('BAI.qlc')
print(', '.join([h for h in lex.header if h not in wl.header]))

# <codecell>

lex.get_scorer(ratio=(1,0), force=True)

# <codecell>

lex.cluster(method='lexstat', threshold=0.6) 

# <codecell>

lex.export('txt', filename='lexstat', sections=dict(h1=("concept", "# Concept: {0}\n"), h2=("lexstatid", "## Cognate Set {0}\n")), item_sep=" ", entry_close="\n")

# <markdowncell>

# Look up the file <a href="files/lexstat.txt">lexstat.txt</a> to see the results.

# <headingcell level=1>

# Align Cognate Sets

# <codecell>

alm = Alignments(lex, ref="lexstatid")
alm.align(scoredict=lex.cscorer)
alm.output('html', filename='alignments')

# <markdowncell>

# Look up the file <a href="files/alignments.html">alignments.html</a> to check the results.

# <headingcell level=1>

# Calculate Trees

# <codecell>

alm.calculate('tree', ref='lexstatid', tree_calc="neighbor")
plot_tree(alm.tree, filename="bai", fileformat="png", bg="white", textcolor="black", textsize=16, degree=45, start=270, figsize=(8,5))
Image('bai.png')

# <headingcell level=1>

# Find Borrowings

# <codecell>

lex.output('qlc', filename="bai_lexstat")
phy = PhyBo('bai_lexstat.qlc', ref="lexstatid", degree=45, start=270, tree_calc="upgma")
phy.analyze()
noo,pdc = phy.get_stats(phy.best_model)
print("Best model is {0} with {1:.2f} origins and {2:.2f} % of patchy cognates.".format(phy.best_model, noo, pdc))

# <codecell>

phy.get_MLN(phy.best_model)
phy.plot_MLN(phy.best_model, fileformat='png', filename='bai_mln', nodestyle="vsd", figsize=(10,6), vsd_scale=0.10)
Image('bai_mln.png')

# <codecell>

D = {}
P = {}
for key in phy:
    pat = phy[key, "patchy"]
    if not pat.endswith("0"):
        tax = phy[key, "taxa"]
        wrd = phy[key, "ipa"]
        con = phy[key, "concept"]
        try:
            D[pat] += [(tax,con,wrd)]
        except:
            D[pat] = [(tax,con,wrd)]
        try:
            P[pat[:-2]] += [pat]
        except:
            P[pat[:-2]] = [pat]
        #print(tax,"\t", con, "\t", wrd, pat)

for pat in P:
    for patchy in sorted(set(P[pat])):
        for a,b,c in D[patchy]:
            print("{0:10}\t{1:10}\t{2:10}\t{3}".format(a,b,c,pat))
        print("")
    print("---\n")

# <headingcell level=1>

# Evaluating Cognate Detection Quality

# <codecell>

a,b,c = bcubes(lex, 'cogid', 'lexstatid')

# <codecell>

lex.cluster(method='edit-dist', threshold=0.5)
a,b,c = bcubes(lex, 'cogid', 'editid')

# <codecell>

lex.cluster(method='turchin')
a,b,c = bcubes(lex, 'cogid', 'turchinid')

# <codecell>

lex.cluster(method='sca', threshold=0.4)
a,b,c = bcubes(lex, 'cogid', 'scaid')

# <codecell>


