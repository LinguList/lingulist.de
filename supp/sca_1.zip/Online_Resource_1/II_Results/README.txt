SCA - Supplementary Material B.b
================================
This folder contains the results of all analyses. The data consists of four
parts:
    
    1. basic - the results for the BASIC analysis,
    2. scale - the results for the SCALE analysis,
    3. sec - the results for the SEC analysis, and
    4. sec_scale - the results for the SEC/SCALE analysis.

Each of these parts contains the results of the analyses for each of the
underlying sound-class models in text-files. For each analysis, the results are
given in two different file formats:

    1. file.psa - the format as it is created by LingPy when carrying out sequence
       alignments using the SCA approach (see the LingPy documentation for
       details), and
    2. file_diff.psa - a specific format for the comparison of alignment
       analyses, where only differing sequences are reported and placed right in
       the same block.
